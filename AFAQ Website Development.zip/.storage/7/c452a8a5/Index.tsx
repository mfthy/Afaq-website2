import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Phone, 
  Users, 
  Database, 
  BarChart, 
  CheckCircle, 
  ArrowRight,
  Star,
  Award,
  Clock,
  Shield
} from 'lucide-react';
import { Link } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function HomePage() {
  const services = [
    {
      icon: Phone,
      title: 'Inbound Call Center',
      description: 'Professional customer service representatives handling your incoming calls 24/7.',
    },
    {
      icon: Users,
      title: 'Outbound Sales',
      description: 'Expert sales teams to help you reach new customers and grow your business.',
    },
    {
      icon: Database,
      title: 'CRM Solutions',
      description: 'Comprehensive customer relationship management systems tailored to your needs.',
    },
    {
      icon: BarChart,
      title: 'Analytics & Reporting',
      description: 'Detailed insights and reports to help you make data-driven decisions.',
    },
  ];

  const features = [
    '24/7 Customer Support',
    'Advanced CRM Integration',
    'Real-time Analytics',
    'Multi-channel Communication',
    'Scalable Solutions',
    'Expert Training Programs'
  ];

  const stats = [
    { number: '500+', label: 'Happy Clients' },
    { number: '10M+', label: 'Calls Handled' },
    { number: '99.9%', label: 'Uptime' },
    { number: '24/7', label: 'Support' },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-blue-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge variant="secondary" className="mb-4">
                Professional Call Center Services
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight">
                Elevate Your 
                <span className="text-blue-600"> Customer Experience</span> with AFAQ
              </h1>
              <p className="text-xl text-gray-600 mt-6 leading-relaxed">
                Transform your business with our comprehensive call center services and 
                advanced CRM solutions. We help companies build stronger customer 
                relationships and drive sustainable growth.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <Button size="lg" asChild>
                  <Link to="/contact">
                    Get Started Today <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link to="/services">
                    View Our Services
                  </Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl p-8 text-white">
                <h3 className="text-2xl font-bold mb-6">Why Choose AFAQ?</h3>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <Award className="h-5 w-5 text-blue-200 mr-3" />
                    <span>Industry-leading expertise</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-blue-200 mr-3" />
                    <span>24/7 reliable support</span>
                  </div>
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 text-blue-200 mr-3" />
                    <span>Secure & compliant solutions</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-5 w-5 text-blue-200 mr-3" />
                    <span>Proven track record</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-blue-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-white mb-2">{stat.number}</div>
                <div className="text-blue-200">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">Our Services</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Comprehensive Call Center & CRM Solutions
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We offer a full range of services designed to enhance your customer 
              relationships and streamline your business operations.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-blue-100 rounded-lg p-3 w-fit">
                    <service.icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge variant="secondary" className="mb-4">Key Features</Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Everything You Need to Succeed
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Our comprehensive platform provides all the tools and features 
                necessary to deliver exceptional customer experiences.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="relative">
              <Card className="p-6">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-600">Call Volume</span>
                    <Badge variant="secondary">+12% from last month</Badge>
                  </div>
                  <div className="h-32 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-end justify-center">
                    <div className="text-white text-center p-4">
                      <div className="text-2xl font-bold">2,847</div>
                      <div className="text-sm opacity-90">Calls Today</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-gray-900">98%</div>
                      <div className="text-sm text-gray-600">Satisfaction</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-gray-900">45s</div>
                      <div className="text-sm text-gray-600">Avg Response</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-gray-900">24/7</div>
                      <div className="text-sm text-gray-600">Availability</div>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Transform Your Customer Experience?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join hundreds of satisfied clients who have improved their customer 
            relationships with our professional call center and CRM solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link to="/contact">
                Start Your Free Consultation <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-blue-600" asChild>
              <Link to="/about">
                Learn More About Us
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}