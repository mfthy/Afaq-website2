import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { 
  Calculator,
  Send,
  CheckCircle,
  Star,
  Users,
  Clock,
  Phone,
  Mail,
  ArrowRight
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function QuotePage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    industry: '',
    companySize: '',
    services: [] as string[],
    callVolume: '',
    timeline: '',
    budget: '',
    requirements: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleServiceChange = (service: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      services: checked 
        ? [...prev.services, service]
        : prev.services.filter(s => s !== service)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "Quote Request Submitted!",
        description: "Our team will prepare a customized quote and contact you within 2 business hours.",
      });
      setIsSubmitting(false);
      setFormData({
        name: '',
        email: '',
        company: '',
        phone: '',
        industry: '',
        companySize: '',
        services: [],
        callVolume: '',
        timeline: '',
        budget: '',
        requirements: ''
      });
    }, 2000);
  };

  const services = [
    { id: 'inbound', name: 'Inbound Call Center', description: 'Customer support, help desk, order processing' },
    { id: 'outbound', name: 'Outbound Sales', description: 'Lead generation, telemarketing, surveys' },
    { id: 'crm', name: 'CRM Solutions', description: 'Implementation, integration, customization' },
    { id: 'analytics', name: 'Analytics & Reporting', description: 'Performance tracking, insights, dashboards' },
    { id: 'multichannel', name: 'Multi-Channel Support', description: 'Phone, email, chat, social media' },
    { id: 'consulting', name: 'Business Consulting', description: 'Process optimization, strategy' }
  ];

  const industries = [
    'Healthcare',
    'Finance & Banking',
    'E-commerce',
    'Technology',
    'Real Estate',
    'Insurance',
    'Telecommunications',
    'Education',
    'Manufacturing',
    'Other'
  ];

  const companySizes = [
    '1-10 employees',
    '11-50 employees',
    '51-200 employees',
    '201-500 employees',
    '500+ employees'
  ];

  const callVolumes = [
    'Less than 100 calls/month',
    '100-500 calls/month',
    '500-2,000 calls/month',
    '2,000-10,000 calls/month',
    '10,000+ calls/month'
  ];

  const timelines = [
    'Immediate (Within 1 week)',
    'Short-term (1-4 weeks)',
    'Medium-term (1-3 months)',
    'Long-term (3+ months)',
    'Not decided yet'
  ];

  const budgetRanges = [
    'Under $5,000/month',
    '$5,000 - $15,000/month',
    '$15,000 - $50,000/month',
    '$50,000 - $100,000/month',
    '$100,000+/month',
    'Not decided yet'
  ];

  const benefits = [
    {
      icon: CheckCircle,
      title: 'Free Consultation',
      description: 'Detailed analysis of your requirements'
    },
    {
      icon: Star,
      title: 'Custom Solution',
      description: 'Tailored to your specific needs'
    },
    {
      icon: Users,
      title: 'Expert Team',
      description: 'Dedicated account management'
    },
    {
      icon: Clock,
      title: 'Quick Response',
      description: 'Quote delivered within 2 business hours'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-blue-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge variant="secondary" className="mb-4">
            Get Your Quote
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Get a 
            <span className="text-blue-600"> Customized Quote</span> for Your Business
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Tell us about your requirements and we'll create a personalized proposal 
            with pricing tailored to your specific needs and goals.
          </p>
        </div>
      </section>

      {/* Quote Form */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            {/* Form */}
            <div className="lg:col-span-2">
              <Card className="p-8">
                <CardHeader className="pb-6">
                  <div className="flex items-center mb-4">
                    <Calculator className="h-6 w-6 text-blue-600 mr-3" />
                    <CardTitle className="text-2xl">Request Your Custom Quote</CardTitle>
                  </div>
                  <CardDescription>
                    Complete the form below and our experts will prepare a detailed proposal for you.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-8">
                    
                    {/* Contact Information */}
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name">Full Name *</Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                            placeholder="John Doe"
                            required
                            className="mt-2"
                          />
                        </div>
                        <div>
                          <Label htmlFor="email">Email Address *</Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleInputChange('email', e.target.value)}
                            placeholder="john@company.com"
                            required
                            className="mt-2"
                          />
                        </div>
                        <div>
                          <Label htmlFor="company">Company Name *</Label>
                          <Input
                            id="company"
                            value={formData.company}
                            onChange={(e) => handleInputChange('company', e.target.value)}
                            placeholder="Your Company"
                            required
                            className="mt-2"
                          />
                        </div>
                        <div>
                          <Label htmlFor="phone">Phone Number *</Label>
                          <Input
                            id="phone"
                            value={formData.phone}
                            onChange={(e) => handleInputChange('phone', e.target.value)}
                            placeholder="+1 (555) 123-4567"
                            required
                            className="mt-2"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Company Details */}
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Company Details</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="industry">Industry *</Label>
                          <Select value={formData.industry} onValueChange={(value) => handleInputChange('industry', value)}>
                            <SelectTrigger className="mt-2">
                              <SelectValue placeholder="Select your industry" />
                            </SelectTrigger>
                            <SelectContent>
                              {industries.map((industry) => (
                                <SelectItem key={industry} value={industry}>
                                  {industry}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="companySize">Company Size *</Label>
                          <Select value={formData.companySize} onValueChange={(value) => handleInputChange('companySize', value)}>
                            <SelectTrigger className="mt-2">
                              <SelectValue placeholder="Select company size" />
                            </SelectTrigger>
                            <SelectContent>
                              {companySizes.map((size) => (
                                <SelectItem key={size} value={size}>
                                  {size}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {/* Services Required */}
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Services Required *</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {services.map((service) => (
                          <div key={service.id} className="flex items-start space-x-3 p-4 border rounded-lg">
                            <Checkbox
                              id={service.id}
                              checked={formData.services.includes(service.id)}
                              onCheckedChange={(checked) => handleServiceChange(service.id, checked as boolean)}
                            />
                            <div className="flex-1">
                              <Label htmlFor={service.id} className="font-medium cursor-pointer">
                                {service.name}
                              </Label>
                              <p className="text-sm text-gray-600 mt-1">
                                {service.description}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Project Details */}
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Project Details</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <Label htmlFor="callVolume">Expected Call Volume</Label>
                          <Select value={formData.callVolume} onValueChange={(value) => handleInputChange('callVolume', value)}>
                            <SelectTrigger className="mt-2">
                              <SelectValue placeholder="Select call volume" />
                            </SelectTrigger>
                            <SelectContent>
                              {callVolumes.map((volume) => (
                                <SelectItem key={volume} value={volume}>
                                  {volume}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="timeline">Project Timeline</Label>
                          <Select value={formData.timeline} onValueChange={(value) => handleInputChange('timeline', value)}>
                            <SelectTrigger className="mt-2">
                              <SelectValue placeholder="Select timeline" />
                            </SelectTrigger>
                            <SelectContent>
                              {timelines.map((timeline) => (
                                <SelectItem key={timeline} value={timeline}>
                                  {timeline}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="mb-4">
                        <Label htmlFor="budget">Budget Range (Optional)</Label>
                        <Select value={formData.budget} onValueChange={(value) => handleInputChange('budget', value)}>
                          <SelectTrigger className="mt-2">
                            <SelectValue placeholder="Select budget range" />
                          </SelectTrigger>
                          <SelectContent>
                            {budgetRanges.map((budget) => (
                              <SelectItem key={budget} value={budget}>
                                {budget}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="requirements">Additional Requirements</Label>
                        <Textarea
                          id="requirements"
                          value={formData.requirements}
                          onChange={(e) => handleInputChange('requirements', e.target.value)}
                          placeholder="Please describe any specific requirements, integrations needed, or additional information that would help us prepare your quote..."
                          className="mt-2 min-h-[120px]"
                        />
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      size="lg" 
                      className="w-full"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>Processing Request...</>
                      ) : (
                        <>
                          Get My Custom Quote <Send className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Benefits Sidebar */}
            <div className="space-y-6">
              <Card className="p-6">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl">What You Get</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-4">
                    {benefits.map((benefit, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <div className="bg-blue-100 rounded-lg p-2">
                          <benefit.icon className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900 mb-1">
                            {benefit.title}
                          </h4>
                          <p className="text-sm text-gray-600">
                            {benefit.description}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl text-blue-900">Need Help?</CardTitle>
                </CardHeader>
                <CardContent className="pt-0 space-y-4">
                  <p className="text-blue-700">
                    Have questions about our services or need assistance with the quote form?
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center text-blue-700">
                      <Phone className="h-4 w-4 mr-2" />
                      <span className="text-sm">+1 (555) 123-4567</span>
                    </div>
                    <div className="flex items-center text-blue-700">
                      <Mail className="h-4 w-4 mr-2" />
                      <span className="text-sm">sales@afaq.com</span>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="w-full border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white">
                    Schedule a Call
                  </Button>
                </CardContent>
              </Card>

              <Card className="p-6">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl">Typical Response Time</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600 mb-2">2 Hours</div>
                    <p className="text-gray-600 text-sm">
                      Our sales team will review your requirements and send you a detailed proposal within 2 business hours.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Ready to Transform Your Customer Experience?
          </h2>
          <p className="text-lg text-blue-100 mb-6 max-w-2xl mx-auto">
            Join hundreds of satisfied clients who have improved their business with AFAQ's solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              <Phone className="mr-2 h-4 w-4" />
              Call for Immediate Assistance
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-blue-600">
              View Our Case Studies <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}