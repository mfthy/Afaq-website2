import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Phone, 
  Users, 
  Database, 
  BarChart, 
  MessageSquare,
  Headphones,
  TrendingUp,
  Shield,
  ArrowRight,
  CheckCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function ServicesPage() {
  const mainServices = [
    {
      icon: Phone,
      title: 'Inbound Call Center Services',
      description: 'Professional customer service representatives handling your incoming calls with expertise and care.',
      features: [
        'Customer Support & Help Desk',
        'Technical Support Services',
        'Order Processing & Management',
        'Appointment Scheduling',
        'Live Chat Support',
        'Email Management'
      ],
      benefits: [
        '24/7 availability',
        'Multilingual support',
        'Reduced operational costs',
        'Improved customer satisfaction'
      ]
    },
    {
      icon: Users,
      title: 'Outbound Call Center Services',
      description: 'Expert sales and marketing teams to help you reach new customers and grow your business.',
      features: [
        'Lead Generation & Qualification',
        'Telemarketing & Sales',
        'Market Research & Surveys',
        'Customer Retention Campaigns',
        'Appointment Setting',
        'Follow-up Services'
      ],
      benefits: [
        'Increased sales revenue',
        'Better lead conversion',
        'Professional sales approach',
        'Scalable campaigns'
      ]
    },
    {
      icon: Database,
      title: 'CRM Solutions & Integration',
      description: 'Comprehensive customer relationship management systems tailored to your specific business needs.',
      features: [
        'Custom CRM Development',
        'CRM Implementation & Setup',
        'Data Migration & Integration',
        'Third-party App Integration',
        'Workflow Automation',
        'User Training & Support'
      ],
      benefits: [
        'Centralized customer data',
        'Improved team collaboration',
        'Automated processes',
        'Better customer insights'
      ]
    },
    {
      icon: BarChart,
      title: 'Analytics & Reporting',
      description: 'Detailed insights and comprehensive reports to help you make informed, data-driven decisions.',
      features: [
        'Real-time Dashboard',
        'Performance Metrics',
        'Call Quality Analysis',
        'Customer Satisfaction Tracking',
        'ROI Reporting',
        'Custom Report Generation'
      ],
      benefits: [
        'Data-driven decisions',
        'Performance optimization',
        'Quality improvement',
        'Strategic planning support'
      ]
    }
  ];

  const additionalServices = [
    {
      icon: MessageSquare,
      title: 'Multi-Channel Support',
      description: 'Seamless customer service across phone, email, chat, and social media platforms.'
    },
    {
      icon: Headphones,
      title: 'Quality Assurance',
      description: 'Comprehensive quality monitoring and training programs to ensure excellence.'
    },
    {
      icon: TrendingUp,
      title: 'Business Consulting',
      description: 'Strategic consulting to optimize your customer service and sales processes.'
    },
    {
      icon: Shield,
      title: 'Compliance & Security',
      description: 'Industry-compliant solutions with robust security measures and data protection.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-blue-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge variant="secondary" className="mb-4">
            Our Services
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Comprehensive Call Center & 
            <span className="text-blue-600"> CRM Solutions</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            From inbound customer service to outbound sales, CRM implementation to advanced analytics, 
            we provide end-to-end solutions that drive business growth and customer satisfaction.
          </p>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-20">
            {mainServices.map((service, index) => (
              <div key={index} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''}`}>
                <div className={index % 2 === 1 ? 'lg:col-start-2' : ''}>
                  <div className="bg-blue-100 rounded-lg p-4 w-fit mb-6">
                    <service.icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">
                    {service.title}
                  </h2>
                  <p className="text-lg text-gray-600 mb-8">
                    {service.description}
                  </p>
                  
                  <div className="mb-8">
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">Key Features:</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {service.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          <span className="text-gray-700 text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button asChild>
                    <Link to="/quote">
                      Get Started <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
                
                <div className={index % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}>
                  <Card className="p-6 h-full">
                    <CardHeader className="pb-4">
                      <CardTitle className="text-lg">Benefits</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="space-y-4">
                        {service.benefits.map((benefit, benefitIndex) => (
                          <div key={benefitIndex} className="flex items-start">
                            <div className="bg-blue-600 rounded-full p-1 mr-3 mt-1">
                              <CheckCircle className="h-3 w-3 text-white" />
                            </div>
                            <span className="text-gray-700">{benefit}</span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-blue-600 mb-1">
                            {index === 0 ? '24/7' : index === 1 ? '300%' : index === 2 ? '50%' : '99.9%'}
                          </div>
                          <div className="text-sm text-gray-600">
                            {index === 0 ? 'Support Coverage' : index === 1 ? 'ROI Increase' : index === 2 ? 'Efficiency Gain' : 'Uptime Guarantee'}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">Additional Services</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Complete Support Ecosystem
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Beyond our core services, we offer specialized solutions to address 
              every aspect of your customer communication needs.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {additionalServices.map((service, index) => (
              <Card key={index} className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-blue-100 rounded-lg p-3 w-fit">
                    <service.icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Let's discuss how our services can help transform your customer 
            experience and drive business growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link to="/quote">
                Request a Quote <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-blue-600" asChild>
              <Link to="/about">
                Learn More About AFAQ
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}