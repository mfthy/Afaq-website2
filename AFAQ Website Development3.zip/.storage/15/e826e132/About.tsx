import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Award, 
  Target, 
  Heart,
  ArrowRight,
  CheckCircle,
  Star,
  Globe,
  Clock,
  TrendingUp
} from 'lucide-react';
import { Link } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function AboutPage() {
  const values = [
    {
      icon: Heart,
      title: 'Customer-Centric',
      description: 'We put our clients and their customers at the heart of everything we do, ensuring exceptional service delivery.'
    },
    {
      icon: Award,
      title: 'Excellence',
      description: 'We strive for excellence in all our operations, continuously improving our services and processes.'
    },
    {
      icon: Target,
      title: 'Results-Driven',
      description: 'We focus on delivering measurable results that drive business growth and customer satisfaction.'
    },
    {
      icon: Users,
      title: 'Teamwork',
      description: 'We believe in the power of collaboration and work together to achieve common goals.'
    }
  ];

  const achievements = [
    {
      icon: Globe,
      number: '15+',
      title: 'Years of Experience',
      description: 'Serving businesses across multiple industries'
    },
    {
      icon: Users,
      number: '500+',
      title: 'Happy Clients',
      description: 'Trusted by companies worldwide'
    },
    {
      icon: Clock,
      number: '10M+',
      title: 'Calls Handled',
      description: 'Successfully processed customer interactions'
    },
    {
      icon: TrendingUp,
      number: '98%',
      title: 'Client Retention',
      description: 'Long-term partnerships built on trust'
    }
  ];

  const timeline = [
    {
      year: '2009',
      title: 'Company Founded',
      description: 'Started as a small call center with a vision to transform customer service'
    },
    {
      year: '2012',
      title: 'CRM Integration',
      description: 'Expanded services to include comprehensive CRM solutions'
    },
    {
      year: '2016',
      title: 'Technology Advancement',
      description: 'Implemented cutting-edge analytics and AI-powered tools'
    },
    {
      year: '2020',
      title: 'Global Expansion',
      description: 'Extended services internationally with 24/7 multilingual support'
    },
    {
      year: '2024',
      title: 'Innovation Leadership',
      description: 'Leading the industry with next-generation customer experience solutions'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-blue-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge variant="secondary" className="mb-4">About AFAQ</Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                Pioneering Excellence in
                <span className="text-blue-600"> Customer Service</span>
              </h1>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                For over 15 years, AFAQ has been at the forefront of transforming how 
                businesses connect with their customers. We combine industry expertise, 
                cutting-edge technology, and a passion for excellence to deliver 
                outstanding results.
              </p>
              <Button size="lg" asChild>
                <Link to="/quote">
                  Partner with Us <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
            <div className="relative">
              <div className="grid grid-cols-2 gap-4">
                {achievements.map((achievement, index) => (
                  <Card key={index} className="p-6 text-center">
                    <div className="bg-blue-100 rounded-lg p-3 w-fit mx-auto mb-4">
                      <achievement.icon className="h-6 w-6 text-blue-600" />
                    </div>
                    <div className="text-2xl font-bold text-gray-900 mb-2">
                      {achievement.number}
                    </div>
                    <div className="font-semibold text-gray-900 mb-2">
                      {achievement.title}
                    </div>
                    <div className="text-sm text-gray-600">
                      {achievement.description}
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <Card className="p-8 border-l-4 border-blue-600">
              <CardHeader className="pb-4">
                <Badge variant="secondary" className="w-fit mb-2">Our Mission</Badge>
                <CardTitle className="text-2xl">Empowering Business Success</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">
                  Our mission is to empower businesses of all sizes with exceptional call center 
                  services and innovative CRM solutions. We are committed to helping our clients 
                  build stronger customer relationships, increase operational efficiency, and 
                  achieve sustainable growth through superior customer experiences.
                </p>
              </CardContent>
            </Card>

            <Card className="p-8 border-l-4 border-green-600">
              <CardHeader className="pb-4">
                <Badge variant="secondary" className="w-fit mb-2">Our Vision</Badge>
                <CardTitle className="text-2xl">Leading the Future</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">
                  To be the global leader in customer experience solutions, setting new standards 
                  for service excellence and innovation. We envision a future where every customer 
                  interaction is meaningful, efficient, and contributes to lasting business 
                  relationships built on trust and satisfaction.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">Our Values</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What Drives Us Forward
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our core values guide every decision we make and shape the way we 
              serve our clients and their customers.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow">
                <div className="bg-blue-100 rounded-full p-4 w-fit mx-auto mb-4">
                  <value.icon className="h-8 w-8 text-blue-600" />
                </div>
                <CardTitle className="text-xl mb-3">{value.title}</CardTitle>
                <CardDescription className="text-gray-600">
                  {value.description}
                </CardDescription>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Company Timeline */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">Our Journey</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              15 Years of Innovation
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From a small startup to an industry leader, here's how we've grown 
              and evolved to better serve our clients.
            </p>
          </div>

          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-blue-200"></div>
            <div className="space-y-12">
              {timeline.map((item, index) => (
                <div key={index} className={`flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8'}`}>
                    <Card className="p-6">
                      <div className="flex items-center mb-3">
                        <Badge variant="outline" className="text-blue-600 border-blue-600">
                          {item.year}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl mb-2">{item.title}</CardTitle>
                      <CardDescription className="text-gray-600">
                        {item.description}
                      </CardDescription>
                    </Card>
                  </div>
                  <div className="relative z-10">
                    <div className="bg-blue-600 rounded-full p-3">
                      <Star className="h-6 w-6 text-white" />
                    </div>
                  </div>
                  <div className="w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">Why Choose AFAQ</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              The AFAQ Advantage
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Here's what sets us apart from other call center and CRM solution providers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="p-6">
              <div className="bg-green-100 rounded-lg p-3 w-fit mb-4">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <CardTitle className="text-xl mb-3">Proven Track Record</CardTitle>
              <CardDescription className="text-gray-600 mb-4">
                With 15+ years of experience and 500+ satisfied clients, we have a 
                proven track record of delivering exceptional results.
              </CardDescription>
              <div className="text-2xl font-bold text-green-600">98%</div>
              <div className="text-sm text-gray-600">Client satisfaction rate</div>
            </Card>

            <Card className="p-6">
              <div className="bg-blue-100 rounded-lg p-3 w-fit mb-4">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
              <CardTitle className="text-xl mb-3">24/7 Support</CardTitle>
              <CardDescription className="text-gray-600 mb-4">
                Round-the-clock support ensures your business never misses an 
                opportunity, regardless of time zones or holidays.
              </CardDescription>
              <div className="text-2xl font-bold text-blue-600">24/7</div>
              <div className="text-sm text-gray-600">Availability guarantee</div>
            </Card>

            <Card className="p-6">
              <div className="bg-purple-100 rounded-lg p-3 w-fit mb-4">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
              <CardTitle className="text-xl mb-3">Scalable Solutions</CardTitle>
              <CardDescription className="text-gray-600 mb-4">
                Our flexible infrastructure grows with your business, ensuring 
                optimal performance at every stage of your growth journey.
              </CardDescription>
              <div className="text-2xl font-bold text-purple-600">300%</div>
              <div className="text-sm text-gray-600">Average ROI increase</div>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Experience the AFAQ Difference?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join the hundreds of businesses that have transformed their customer 
            experience with our expert solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link to="/quote">
                Start Your Journey <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-blue-600" asChild>
              <Link to="/services">
                Explore Our Services
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}